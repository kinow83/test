#!/bin/bash
# µðºñ »ý¼º, È¨ÆäÀÌÁö ·Î±×ÀÎ Á¤º¸ µî·Ï
echo "Input your DB sever password"
read _password

$(mysql -u root -p$_password < db.script)

if [ $? = 0 ]
then 
#echo $(sed s/#define PASSWORD ""/#define PASSWORD "$_password"/g include/config.h > .a; cat .a > include/config.h)
   echo "Input Login ipaddress in web server"
   read _webipaddress
   echo "Input Login ID in web server"
   read _webID
   echo "Input Login password in web server"
   read _webpassword

   echo "insert into information.member(ip, name, pass) values('$_webipaddress','$_webID',md5('$_webpassword'));" > .db.tmp
   echo $(mysql -u root -p$_password < .db.tmp)
   echo $(rm -fr .db.tmp)
fi
   
