
#pragma once

#include "../config.h"
#include "../radvd.h"

void print_safe_buffer(struct safe_buffer * sb);

